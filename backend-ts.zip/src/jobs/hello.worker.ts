import { startHelloWorker } from "./bullmq.provider";
startHelloWorker();
